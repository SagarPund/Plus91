<?php

require 'connection.php';

//Dynamic table name
$table = $_REQUEST['table'];

//Table columns
$columns = array(
    array('db' => 'ID', 'dt' => 0),
    array('db' => 'EMPID', 'dt' => 1),
    array('db' => 'FNAME', 'dt' => 2),
    array('db' => 'LNAME', 'dt' => 3),
    array('db' => 'SEX', 'dt' => 4),
    array('db' => 'BIRTHDATE', 'dt' => 5),
    array('db' => 'JOININGDATE', 'dt' => 6),
    array('db' => 'EMAIL', 'dt' => 7),
    array('db' => 'CONTACT', 'dt' => 8),
    array('db' => 'LOCATION', 'dt' => 9),
    array('db' => 'DEPT', 'dt' => 10),
    array('db' => 'SALARY', 'dt' => 11)
);

if($table=='failed_employee'){
    array_push($columns,array('db' => 'REASON', 'dt' => 12));
}

$requestData = $_REQUEST;

// Get total number of records
$sql = "SELECT COUNT(*) AS total FROM $table";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$totalRecords = $row["total"];

//apply filters if any
$searchValue = $requestData['search']['value'];
$searchQuery = "";
if (!empty($searchValue)) {
    $searchQuery = " WHERE (Empid LIKE '%$searchValue%' OR FName LIKE '%$searchValue%' OR LName LIKE '%$searchValue%' OR MName LIKE '%$searchValue%' OR Sex LIKE '%$searchValue%' OR Birthdate LIKE '%$searchValue%' OR Joiningdate LIKE '%$searchValue%' OR Email LIKE '%$searchValue%' OR Contact LIKE '%$searchValue%' OR Location LIKE '%$searchValue%' OR Dept LIKE '%$searchValue%' OR Salary LIKE '%$searchValue%'";
    if($table=='failed_employee'){
        $searchQuery.= " OR reason LIKE '%$searchValue%'";
    }
    $searchQuery.= " )";
}

// Get records after applying filter
$sql = "SELECT COUNT(*) AS totalFiltered FROM $table" . $searchQuery;
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$totalFiltered = $row["totalFiltered"];

// Order by
$columnIndex = intval($requestData['order'][0]['column']);
$column = $columns[$columnIndex];
$order = $column['db'];
$dir = $requestData['order'][0]['dir'];

// Pagination
$start = intval($requestData['start']);
$length = intval($requestData['length']);

// Get records
$sql = "SELECT * FROM $table $searchQuery ORDER BY $order $dir LIMIT $start, $length";
$result = $conn->query($sql);

$data = array();
while ($row = $result->fetch_assoc()) {
    
    $Birthdate   = ($row['Birthdate']) ? date('d M Y',strtotime($row['Birthdate'])): '';
    $Joiningdate = ($row['Joiningdate'])? date('d M Y',strtotime($row['Joiningdate'])): '';
    if($table=='failed_employee'){
        
        $data[] = array(
            $row['Empid'],
            $row['FName'],
            $row['MName'],
            $row['LName'],
            $row['Sex'],
            $Birthdate,
            $Joiningdate,
            $row['Email'],
            $row['Contact'],
            $row['Location'],
            $row['Dept'],
            $row['Salary'],
            $row['reason']
        );
    } else {
        $data[] = array(
            $row['Empid'],
            $row['FName'],
            $row['MName'],
            $row['LName'],
            $row['Sex'],
            $Birthdate,
            $Joiningdate,
            $row['Email'],
            $row['Contact'],
            $row['Location'],
            $row['Dept'],
            $row['Salary']
        );
    }
}

$response = array(
    "draw" => intval($requestData['draw']),
    "recordsTotal" => intval($totalRecords),
    "recordsFiltered" => intval($totalFiltered),
    "data" => $data
);

echo json_encode($response);

$conn->close();
?>
