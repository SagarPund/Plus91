<?php

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "plus91";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
} catch (\Exception $e) {
    
    echo $e->getMessage(), PHP_EOL;
}

?>