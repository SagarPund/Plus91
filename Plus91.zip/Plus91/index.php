<!DOCTYPE html>
<html>
<head>
    <title>Upload Excel File</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
</head>
<body>
    <h2>Upload Excel File</h2>
    <form id="uploadForm" enctype="multipart/form-data">
        <input type="file" name="file" id="file">
        <input type="submit" value="Upload" id="uploadBtn">
    </form>
    <br>
    <div id="progressBar" style="display: none;">
        <progress id="progress" value="0" max="100"></progress>
        <span id="progressLabel">0%</span>
    </div>
    <br>
    <div id="result"></div>

    <h2>Failed Records</h2>
    <table id="dataTable" class="display nowrap" style="width:100%">
        <thead>
            <tr>
                <th>EmpId</th>
                <th>FName</th>
                <th>MName</th>
                <th>LName</th>
                <th>Sex</th>
                <th>Birth Date</th>
                <th>Joining Date</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Location</th>
                <th>Dept</th>
                <th>Salary</th>
                <th>Reason</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <hr/>

    <h2>Success Records</h2>
    <table id="dataTable1" class="display nowrap" style="width:100%">
        <thead>
            <tr>
                <th>EmpId</th>
                <th>FName</th>
                <th>MName</th>
                <th>LName</th>
                <th>Sex</th>
                <th>Birth Date</th>
                <th>Joining Date</th>
                <th>Email</th>
                <th>Contact</th>
                <th>Location</th>
                <th>Dept</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#uploadForm").on("submit", function(event) {
                event.preventDefault();

                var fileInput = document.getElementById('file');
                var file = fileInput.files[0];
                
                if (!file) {
                alert('Please select a file.');
                return;
                }
                
                var fileType = file.type;
                if (fileType !== 'application/vnd.ms-excel') {
                alert('File type must be XLSX.');
                return;
                }
                
                $("#result").html("");
                $("#progressBar").show();

                var formData = new FormData(this);
                $.ajax({
                    url: "upload.php",
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        xhr.upload.addEventListener("progress", function(evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = Math.round((evt.loaded / evt.total) * 100);
                                $("#progress").val(percentComplete);
                                $("#progressLabel").text(percentComplete + "%");
                            }
                        }, false);
                        return xhr;
                    },
                    success: function(response) {
                        $('#result').html(response);
                        loadTables();
                        $("#uploadForm").reset();
                    }
                });
            });

            function loadTables(){

                if ($.fn.dataTable.isDataTable('#dataTable')) {
                    $('#dataTable').DataTable().clear().destroy();               
                }

                var myTable = $('#dataTable').DataTable({
                    
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
                    "responsive": true,
                    "ajax": {
                        url: "get_records.php",
                        type: "POST",
                        data:{"table":"failed_employee"}
                    }
                });

                if ($.fn.dataTable.isDataTable('#dataTable1')) {
                    $('#dataTable1').DataTable().clear().destroy();               
                }

                var myTable1 = $('#dataTable1').DataTable({
                    
                    "processing": true,
                    "serverSide": true,
                    "destroy": true,
                    "responsive": true,
                    "ajax": {
                        url: "get_records.php",
                        type: "POST",
                        data:{"table":"employee"},
                        error: function (xhr, error, thrown) {
                            $('#result').html('<span style="color:red">Database does not exists!.</span>');
                        }
                    }
                });
            }

            loadTables();
        });
    </script>
</body>
</html>
