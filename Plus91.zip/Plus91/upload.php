<?php

require 'vendor/autoload.php';
require 'connection.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if (!empty($_FILES['file']['name'])) {

    //clear db tables
    clearDBTable($conn,'failed_employee');
    clearDBTable($conn,'employee');

    //unlink previous all files
    $files = glob('uploads/*');
    foreach($files as $file){
        if(is_file($file)) {
            unlink($file);
        }
    }

    $target_dir = "uploads/";
    $target_file = $target_dir . time().'_'.basename($_FILES["file"]["name"]);
    $is_file_upload = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Allow xls file formats only
    if($imageFileType != "xls" ) {
        echo "Sorry, only .xls files are allowed.";
        $is_file_upload = 0;
    }

    if ($is_file_upload == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            echo "The file ". htmlspecialchars( basename( $_FILES["file"]["name"])). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    $spreadsheet = IOFactory::load($target_file);
    $worksheet = $spreadsheet->getActiveSheet();

    $highestRow = $worksheet->getHighestRow();
    $highestColumn = $worksheet->getHighestColumn();
    $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn);

    $successCount = 0;
    $failedCount = 0;
    
    for ($row = 2; $row <= $highestRow; $row++) {
        
        $rowData = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,NULL,TRUE,FALSE);
        if(isEmptyRow(reset($rowData))) { continue; } // skip empty row
        $rowData = [];
        for ($col = 1; $col <= $highestColumnIndex; $col++) {
            $cellValue = $worksheet->getCellByColumnAndRow($col, $row)->getValue();
            $rowData[$worksheet->getCellByColumnAndRow($col, 1)->getValue()] = $cellValue;
        }

        $rowData['BIRTHDAY']    = formatDate($rowData['BIRTHDAY']);
        $rowData['JOININGDATE'] = formatDate($rowData['JOININGDATE']);

        //Validate data
        $validation_result = validateData($rowData);
        if ($validation_result['msg']=='') {

            $res = commonInsertfunction('employee',$rowData,$conn);

            if ($res) {
                $successCount++;
            } else {
                $failedCount++;

                array_push($rowData,'Something went wrong at DB side!.');
                commonInsertfunction('failed_employee',$rowData,$conn);
            }
            
        } else {
            $failedCount++;

            array_push($rowData,$validation_result['msg']);
            commonInsertfunction('failed_employee',$rowData,$conn);
        }
    
    }

    //Success and Failed Summary Count
    $response = '<p><strong>Summary:</strong></p>';
    $response .= '<p>Successful records: ' . $successCount . '</p>';
    $response .= '<p>Failed records: ' . $failedCount . '</p>';

    $conn->close();
    echo $response;
}

// Function to validate data
function validateData($data) {

    $validation_flag = false;
    $validation_msg = '';

    /****
        Note: I check only validation like
        1. All fields should not be blank(i.e. blank field validation)
        2. Vaild email format.
        3. Vaild mobile format.

        Same way we can add more validation as per requirements.
    */

    if(!empty($data)){
        foreach($data as $key => $value){
            if($value==''){
                $validation_flag = false;
                if($validation_msg!=''){ $validation_msg.= '<br/>'; }
                $validation_msg.= 'Column '.ucfirst(strtolower($key)).' cannot be blank.';
                //break;
            } else {
                $validation_flag = true;
            }

            if($key=='EMAIL'){
                if(filter_var($value, FILTER_VALIDATE_EMAIL)){
                    $validation_flag = true;
                } else {
                    $validation_flag = false;
                    if($validation_msg!=''){ $validation_msg.= '<br/>'; }
                    $validation_msg.= 'Email should be valid format.';
                }
            }

            if($key=='CONTACT'){
                
                $mobileNumber = preg_replace("/[^0-9]/", "", $value);

                if (strlen($mobileNumber) === 10 && preg_match("/^[0-9]{10}$/", $mobileNumber)) {
                    $validation_flag = true;
                } else {
                    $validation_flag = false;
                    if($validation_msg!=''){ $validation_msg.= '<br/>'; }
                    $validation_msg.= 'Mobile number is invalid.';
                }
            }
        }
    }
    return array('flag'=>$validation_flag,'msg'=>$validation_msg);
}

// Function to clear table
function clearDBTable($conn,$tablename){

    $stmt_clear_table = $conn->prepare("TRUNCATE TABLE $tablename;");
    $stmt_clear_table->execute();
    $stmt_clear_table->close();

}

// Function to common insert data
function commonInsertfunction($tablename,$data,$conn){

    $parameter = str_repeat('?,', count($data));
    $parameter = rtrim($parameter,',');
    $sql = "INSERT INTO $tablename (Empid,FName,MName,LName,Sex,Birthdate,Joiningdate,Email,Contact,Location,Dept,Salary";
    if($tablename=='failed_employee'){
        $sql.= ",reason";
    }
    $sql.= ") VALUES ($parameter)";
    $stmt = $conn->prepare($sql);

    $params = array();
    foreach($data as $fieldname => $value){
        $params[] = $value;
    }

    $success = false;
    if($stmt->execute($params)){
        $success = true;
    }
    $stmt->close();

    return $success;
    
}

// Format date
function formatDate($input_date){

    $date = new DateTime('1899-12-31');
    $date->modify("+$input_date day -1 day");
    return $date->format('Y-m-d');

}

//Check Xslx row empty
function isEmptyRow($row) {
    foreach($row as $cell){
        if (null !== $cell) return false;
    }
    return true;
}
?>
